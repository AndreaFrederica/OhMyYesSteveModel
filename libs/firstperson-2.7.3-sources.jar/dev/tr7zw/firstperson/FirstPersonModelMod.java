package dev.tr7zw.firstperson;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(
        modid = Reference.MOD_ID,
        name = Reference.MOD_NAME,
        version = Reference.VERSION,
        clientSideOnly = true,
        acceptableRemoteVersions = "*",
        guiFactory = "dev.tr7zw.firstperson.config.ConfigGuiFactory"
)
public final class FirstPersonModelMod {
    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        if (event.getSide().isClient()) {
            FirstPersonModelCore.instance.initialize(event.getSuggestedConfigurationFile());
        }
    }
}
