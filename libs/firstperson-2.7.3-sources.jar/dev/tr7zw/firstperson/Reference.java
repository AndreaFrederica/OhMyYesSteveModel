package dev.tr7zw.firstperson;

/**
 * Tags storage class, you can change at will
 */
public final class Reference {
    private Reference() {
    }

    public static final String MOD_ID = "firstperson";
    public static final String MOD_NAME = "First-person Model";
    public static final String VERSION = "2.7.3";

}
