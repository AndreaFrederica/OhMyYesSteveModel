package dev.tr7zw.firstperson.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.tr7zw.firstperson.FirstPersonModelCore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderFish;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Items;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.math.Vec3d;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(RenderFish.class)
public abstract class RenderFishMixin {
    @Unique private Vec3d firstperson$lineOffset = Vec3d.ZERO;
    @Unique private boolean firstperson$modelRod;

    @WrapMethod(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V")
    private void firstperson$line(EntityFishHook hook, double x, double y, double z, float yaw, float delta,
                                  Operation<Void> original) {
        Vec3d savedOffset = firstperson$lineOffset;
        boolean savedMode = firstperson$modelRod;
        FirstPersonModelCore core = FirstPersonModelCore.instance;
        var player = Minecraft.getMinecraft().player;
        firstperson$modelRod = false;
        firstperson$lineOffset = Vec3d.ZERO;
        try {
            if (player != null && hook.getAngler() == player && core.shouldRenderBody()) {
                EnumHandSide side = player.getHeldItemMainhand().getItem() == Items.FISHING_ROD
                        ? player.getPrimaryHand() : player.getPrimaryHand().opposite();
                firstperson$modelRod = !core.hideArm(side);
                if (firstperson$modelRod) firstperson$lineOffset = core.offset(player, delta);
            }
            original.call(hook, x, y, z, yaw, delta);
        } finally {
            firstperson$lineOffset = savedOffset;
            firstperson$modelRod = savedMode;
        }
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/client/settings/GameSettings;thirdPersonView:I", ordinal = 1, opcode = Opcodes.GETFIELD))
    private int firstperson$rodPerspective(GameSettings instance, Operation<Integer> original) {
        return firstperson$modelRod ? 1 : original.call(instance);
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/EntityPlayer;posX:D", opcode = Opcodes.GETFIELD))
    private double firstperson$x(EntityPlayer instance, Operation<Double> original) {
        return original.call(instance) + firstperson$lineOffset.x;
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/EntityPlayer;prevPosX:D", opcode = Opcodes.GETFIELD))
    private double firstperson$previousX(EntityPlayer instance, Operation<Double> original) {
        return original.call(instance) + firstperson$lineOffset.x;
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/EntityPlayer;posY:D", opcode = Opcodes.GETFIELD))
    private double firstperson$y(EntityPlayer instance, Operation<Double> original) {
        return original.call(instance) + firstperson$lineOffset.y;
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/EntityPlayer;prevPosY:D", opcode = Opcodes.GETFIELD))
    private double firstperson$previousY(EntityPlayer instance, Operation<Double> original) {
        return original.call(instance) + firstperson$lineOffset.y;
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/EntityPlayer;posZ:D", opcode = Opcodes.GETFIELD))
    private double firstperson$z(EntityPlayer instance, Operation<Double> original) {
        return original.call(instance) + firstperson$lineOffset.z;
    }

    @WrapOperation(method = "doRender(Lnet/minecraft/entity/projectile/EntityFishHook;DDDFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/EntityPlayer;prevPosZ:D", opcode = Opcodes.GETFIELD))
    private double firstperson$previousZ(EntityPlayer instance, Operation<Double> original) {
        return original.call(instance) + firstperson$lineOffset.z;
    }
}
