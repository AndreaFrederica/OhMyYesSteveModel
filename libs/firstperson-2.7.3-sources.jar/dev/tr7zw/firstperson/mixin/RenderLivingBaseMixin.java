package dev.tr7zw.firstperson.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import dev.tr7zw.firstperson.FirstPersonModelCore;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerArrow;
import net.minecraft.client.renderer.entity.layers.LayerCape;
import net.minecraft.client.renderer.entity.layers.LayerElytra;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
import net.minecraft.client.renderer.entity.layers.LayerDeadmau5Head;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(RenderLivingBase.class)
public abstract class RenderLivingBaseMixin {
    @WrapWithCondition(method = "renderLayers", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/layers/LayerRenderer;doRenderLayer(Lnet/minecraft/entity/EntityLivingBase;FFFFFFF)V"))
    private <T extends EntityLivingBase> boolean firstperson$filterLayers(LayerRenderer<T> layer, T entity, float limbSwing, float amount, float delta, float age, float yaw, float pitch, float scale) {
        FirstPersonModelCore core = FirstPersonModelCore.instance;
        if (core.isRenderingPlayer()) {
            return !(layer instanceof LayerCustomHead)
                    && !(layer instanceof LayerDeadmau5Head)
                    && (!(layer instanceof LayerArrow) || core.getConfig().renderStuckFeatures)
                    && (!core.hideSwimmingBody() || (!(layer instanceof LayerCape) && !(layer instanceof LayerElytra)))
                    && !core.getConfig().hiddenLayers.contains(layer.getClass().getName());
        }
        return true;
    }
}
