package dev.tr7zw.firstperson.mixin;

import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import dev.tr7zw.firstperson.FirstPersonModelCore;
import dev.tr7zw.firstperson.config.FirstPersonSettings.VanillaHands;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @SuppressWarnings("ShadowNameDoesntMatchTargetClass")
    @Shadow protected abstract void renderArmFirstPerson(float equip, float swingProgress, EnumHandSide hand);

    @Inject(method = "renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V",
            at = @At("HEAD"), cancellable = true)
    private void firstperson$hands(AbstractClientPlayer player, float delta, float pitch, EnumHand hand,
            float swing, ItemStack stack, float equip, CallbackInfo ci) {
        FirstPersonModelCore core = FirstPersonModelCore.instance;
        if (!core.shouldRenderBody()) return;
        if (!core.showVanillaHands()) { ci.cancel(); return; }
        if (core.getConfig().vanillaHandsMode == VanillaHands.ALL_DOUBLE && hand == EnumHand.OFF_HAND
                && stack.isEmpty() && !player.isInvisible() && player.getHeldItemMainhand().getItem() != Items.FILLED_MAP) {
            GlStateManager.pushMatrix();
            try { renderArmFirstPerson(equip, swing, player.getPrimaryHand().opposite()); }
            finally { GlStateManager.popMatrix(); }
        }
    }

    @WrapMethod(method = "renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V")
    private void firstperson$lowerHands(AbstractClientPlayer player, float partialTicks, float rotationPitch, EnumHand hand, float swingProgress, ItemStack stack, float equip, Operation<Void> original) {
        FirstPersonModelCore core = FirstPersonModelCore.instance;
        if (core.shouldRenderBody() && core.dynamicHandsEnabled()) {
            float pitch = Minecraft.getMinecraft().player.rotationPitch;
            if (pitch > 15) equip = MathHelper.clamp((pitch - 15) / 20f * 1.2f, equip, 1.2f);
        }
        original.call(player, partialTicks, rotationPitch, hand, swingProgress, stack, equip);
    }
}
