package dev.tr7zw.firstperson;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

public final class FirstPersonPlugin implements IFMLLoadingPlugin {
}
